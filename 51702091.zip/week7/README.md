# Em là Trần Ngọc Bảo Duy - 51702091

# Folder Code chứa các code implent: thầy chạy file em liệt kê bên dưới để có thể test code, trong đó em có giải thích rồi ạ
- em làm ví dụ về soft max về phân loại spam message nằm trong file Softmax_Classification_Spam_Message.ipynb, ví dụ này có phần xử lí text với data processing hơi lớn vì phải xây dựng dictionary => doc2vec cho các message 
- vì vậy em làm bài này trên google colab

# file Softmax_function.pdf
- tìm hiểu về soft max function 